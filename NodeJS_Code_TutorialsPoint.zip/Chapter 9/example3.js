//BUFFERS
//example3.js

var buf = new Buffer('Bufferville');

var json = buf.toJSON(buf);

console.log(json);

//When the above program is executed, it produces the following result:
//[ 66, 117, 102, 102, 101, 114, 118, 105, 108, 108, 101 ]