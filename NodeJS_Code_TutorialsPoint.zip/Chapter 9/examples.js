//BUFFERS
//examples.js


//example1.js

buf = new Buffer(256);
len = buf.write("Buffercity");

console.log("Octets written : " + len);

//When the above program is executed, it produces the following result:
//Octets written : 10



//example2.js

buf = new Buffer(26);

for (var i = 0; i < 26; i++) {
    buf[i] = i + 97;
}

console.log(buf.toString('ascii'));
// outputs: abcdefghijklmnopqrstuvwxyz

console.log(buf.toString('ascii', 0, 5));
// outputs: abcde

console.log(buf.toString('utf8', 0, 5));
// outputs: abcde

console.log(buf.toString(undefined, 0, 5));
// encoding defaults to 'utf8', outputs abcde




//example3.js

var buf = new Buffer('Bufferville');

var json = buf.toJSON(buf);

console.log(json);

//When the above program is executed, it produces the following result:
//[ 66, 117, 102, 102, 101, 114, 118, 105, 108, 108, 101 ]



//example4.js

var buffer1 = new Buffer('Buffer are  ');
var buffer2 = new Buffer('Great for Testing');
var buffer3 = Buffer.concat([buffer1, buffer2]);

console.log("buffer3 content: " + buffer3.toString());
//When the above program is executed, it produces the following result:
//buffer3 content:  Buffer are  Great for Testing



//example5.js

var buffer1 = new Buffer('ABC');
var buffer2 = new Buffer('ABCD');
var result = buffer1.compare(buffer2);
if (result < 0) {
    console.log(buffer1 + " comes before " + buffer2);
} else if (result == 0) {
    console.log(buffer1 + " is same as " + buffer2);
} else {
    console.log(buffer1 + " comes after " + buffer2);
} 

//When the above program is executed, it produces the following result:
//ABC comes before ABCD



//example6.js

var buffer1 = new Buffer('ABC');
//copy a buffer
var buffer2 = new Buffer(3);
buffer1.copy(buffer2);

console.log("buffer2 content: " + buffer2.toString());
//When the above program is executed, it produces the following result:
//buffer2 content: ABC



//example7.js

var buffer1 = new Buffer('Olympic Games 2020');
//slicing a buffer
var buffer2 = buffer1.slice(0,9);

console.log("buffer2 content: " + buffer2.toString());
//When the above program is executed, it produces the following result:
//buffer2 content: Olympic G



//example8.js

var buffer = new Buffer('Olympic Games 2020');
//length of the buffer

console.log("buffer length: " + buffer.length);

//When the above program is executed, it produces the following result:
//buffer length: 18



