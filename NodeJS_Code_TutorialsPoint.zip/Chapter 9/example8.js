//BUFFERS
//example8.js

var buffer = new Buffer('Olympic Games 2020');

//length of the buffer
console.log("buffer length: " + buffer.length);

//When the above program is executed, it produces the following result:
//buffer length: 18