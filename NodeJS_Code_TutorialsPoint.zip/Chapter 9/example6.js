//BUFFERS
//example6.js

var buffer1 = new Buffer('ABC');

//copy a buffer
var buffer2 = new Buffer(3);
buffer1.copy(buffer2);

console.log("buffer2 content: " + buffer2.toString());
//When the above program is executed, it produces the following result:
//buffer2 content: ABC