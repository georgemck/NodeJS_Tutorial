//BUFFERS
//methods.js

var buf = new Buffer(10);
console.log(buf);

var buf = new Buffer([10, 20, 30, 40, 50]);
console.log(buf);

var buf = new Buffer("Simply Easy Learning", "utf-8");
console.log(buf);

