//BUFFERS
//example1.js

buf = new Buffer(256);
len = buf.write("Buffercity");

console.log("Octets written : " + len);

//When the above program is executed, it produces the following result:
//Octets written : 10