//BUFFERS
//example7.js

var buffer1 = new Buffer('Olympic Games 2020');

//slicing a buffer
var buffer2 = buffer1.slice(0,9);

console.log("buffer2 content: " + buffer2.toString());
//When the above program is executed, it produces the following result:
//buffer2 content: Olympic G