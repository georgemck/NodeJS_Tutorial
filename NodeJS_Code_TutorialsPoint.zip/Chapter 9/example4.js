//BUFFERS
//example4.js

var buffer1 = new Buffer('Buffer are  ');
var buffer2 = new Buffer('Great for Testing');
var buffer3 = Buffer.concat([buffer1, buffer2]);

console.log("buffer3 content: " + buffer3.toString());
//When the above program is executed, it produces the following result:
//buffer3 content:  Buffer are  Great for Testing