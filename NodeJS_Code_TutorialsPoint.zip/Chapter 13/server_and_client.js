//UTILITY MODULES
//server_and_client.js

var net = require('net');

var server = net.createServer(function (connection) {
  console.log('client connected');
  connection.on('end', function () {
    console.log('client disconnected');
  });

  connection.write('Hello World!\r\n');
  connection.pipe(connection);
});

server.listen(8080, function () {

  //wait 4 seconds before attempting to create the client that will connect to the server (127.0.0.1)
  setTimeout(function () {
    console.log("connect to server");
    client = net.connect({ host: "127.0.0.1", port: 8080 }, function () {
      console.log('connected to server!');
    });
    client.on('data', function (data) {
      console.log(data.toString());
      client.end();
    });

    client.on('end', function () {
      console.log('disconnected from server');
    });

  }, 4000);

});


