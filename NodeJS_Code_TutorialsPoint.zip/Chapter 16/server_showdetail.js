//RESTFUL API
//server_showdetail.js

var express = require('express');
var app = express();
var fs = require("fs");

app.get('/:id', function (req, res) {
    // First read existing users.
    fs.readFile(__dirname + "/" + "users.json", 'utf8', function (err, data) {
        data = JSON.parse(data);
        var user = data["user" + req.params.id];//typo was users but actually is data
        console.log(user);
        res.end(JSON.stringify(user));
    });
});

var server = app.listen(8081, "127.0.0.1", function () {
    var host = server.address().address;
    var port = server.address().port;
    console.log("Example app listening at http://%s:%s", host, port);
});