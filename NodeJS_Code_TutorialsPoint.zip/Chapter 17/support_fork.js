//SCALING AN APPLICATION
//support_fork.js

console.log("Child Process " + process.argv[2] + " executed." );