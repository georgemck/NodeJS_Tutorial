//ENVIRONMENT SETUP
//main.js

/*
    open a command prompt and type:
        node main.js
    and press the Enter key

    "Hello, World!" should display 
*/

console.log("Hello, World!");


