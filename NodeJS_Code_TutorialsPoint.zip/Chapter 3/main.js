//FIRST APPLICATION
//main.js


//Chapter 3 : First Application - a very simple web server

//define a variable that will become the http server
var http;

//assign the server variable to load the http module built into Node.js
http = require("http");

//create the web server which will accept URL requests and send HTTP response back to the connecting client
http.createServer(function (request, response) {
    // Send the HTTP header
    // HTTP Status: 200 : OK
    // Content Type: text/plain
    response.writeHead(200, { 'Content-Type': 'text/plain' });

    // Send the response body as "Hello World"
    response.end('Hello World\n');
}).listen(8081); //listening/accepting requests on port 8081

// Console will print the message (not visible to client)
console.log('Server running at http://127.0.0.1:8081/');

// to see this example use a web browser on the same computer, open the page http://127.0.0.1:8081

//note the program does not end. The web server awaits requests to fulfill