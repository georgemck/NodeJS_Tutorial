//GLOBAL OBJECTS
//main_timeout.js

//setting a timeout
function printHello() {
    console.log("Hello, World!");
}

// run the printHello function once after 2 seconds with the following
setTimeout(printHello, 2000);





// Now call above function after 2 seconds
var t = setTimeout(printHello, 2000);

// Now clear the timer by uncommenting the line below and running again
//clearTimeout(t); //prevents the timer from running, clears before 2 seconds for its trigger
