//GLOBAL OBJECTS
//main_interval.js

function printHello() {
    console.log("Hello, World!");
}

// Now call above function every 2 seconds
setInterval(printHello, 2000);





// Now call above function after 2 seconds
var t = setInterval(printHello, 2000);

// Now clear the interval by uncommenting the line below and running again
//clearInterval(t); //prevents the timer from running, clears before 2 seconds for its trigger
