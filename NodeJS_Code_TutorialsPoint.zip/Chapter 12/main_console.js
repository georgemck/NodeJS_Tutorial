//GLOBAL OBJECTS
//main_console.js

console.info("Program Started");

var counter = 10;

console.log("Counter: %d", counter);

console.time("Getting data");

//
// Do some processing here...
//

console.timeEnd('Getting data');

console.info("Program Ended");