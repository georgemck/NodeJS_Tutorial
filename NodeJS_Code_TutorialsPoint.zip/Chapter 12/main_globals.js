//GLOBAL OBJECTS
//main_globals.js

//https://nodejs.org/api/globals.html#globals_filename
//will not run in REPL

// Let's try to print the value of __filename
console.log( __filename );

// Let's try to print the value of __dirname
console.log( __dirname );

