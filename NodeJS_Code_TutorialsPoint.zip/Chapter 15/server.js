//EXPRESS FRAMEWORK
//server.js

var express = require('express');
var app = express();

app.get('/', function (req, res) {
    res.send('Hello World');
})

//added "127.0.0.1" as second parameter for the host to be setup properly
var server = app.listen(8081, "127.0.0.1", function () {
    var host = server.address().address;
    var port = server.address().port;

    console.log("Example app listening at http://%s:%s", host, port)
});