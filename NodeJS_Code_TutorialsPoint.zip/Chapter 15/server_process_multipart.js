//EXPRESS FRAMEWORK
//server_process_multipart.js

var express = require('express');
var app = express();
var fs = require("fs");
var bodyParser = require('body-parser');

//https://www.npmjs.com/package/multer
var multer = require('multer');

app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: false }));

app.use(multer({ dest: '/tmp/' }).single('file'));
//tmp is in the root of the server directory 
//file is the name property from the HTML form field
//https://www.npmjs.com/package/multer

app.get('/index.htm', function (req, res) {
    res.sendFile(__dirname + "/" + "index_multipart.htm");
});

app.post('/file_upload', function (req, res) {
    var originalname = req.file.originalname;
    var path = req.file.path;
    var file = __dirname + "/" + originalname;

    fs.readFile(path, function (err, data) {
        fs.writeFile(file, data, function (err) {
            if (err) {
                console.log(err);
            } else {
                response = {
                    message: 'File uploaded successfully',
                    filename: originalname
                };
            }
            console.log(response);
            res.end(JSON.stringify(response));
        });
    });
})

var server = app.listen(8081, "127.0.0.1", function () {
    var host = server.address().address;
    var port = server.address().port;
    console.log("Example app listening at http://%s:%s", host, port)
});